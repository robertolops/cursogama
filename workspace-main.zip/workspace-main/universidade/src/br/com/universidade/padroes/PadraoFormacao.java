package br.com.universidade.padroes;

public interface PadraoFormacao {

	double calcularMensalidade(float fator);
	void definirDuracao();
}
