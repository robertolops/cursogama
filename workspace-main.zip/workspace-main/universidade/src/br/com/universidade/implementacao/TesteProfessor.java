package br.com.universidade.implementacao;

import javax.swing.JOptionPane;

import br.com.universidade.modelo.Endereco;
import br.com.universidade.modelo.Professor;

public class TesteProfessor {

	public static void main(String[] args) {
		
		Endereco endereco = new Endereco();
		endereco.setLogradouro(JOptionPane.showInputDialog("Logradouro"));
		endereco.setBairro(JOptionPane.showInputDialog("Bairro"));
		endereco.setCidade(JOptionPane.showInputDialog("Cidade"));
		// preencheria o restante dos atributos
		
		Professor p = new Professor();
		p.setId(Integer.parseInt(JOptionPane.showInputDialog("ID")));
		p.setNome(JOptionPane.showInputDialog("Nome").toUpperCase());
		p.setValorHora(Float.parseFloat(JOptionPane.showInputDialog("Valor")));
		p.setFormacao(JOptionPane.showInputDialog("Forma��o").toUpperCase());
		p.setEndereco(endereco);
	
		System.out.println("Nome: " + p.getNome());
		System.out.println(p.getFormacao());
		System.out.println(p.getValorHora());
		System.out.println(p.getEndereco().getLogradouro());
	}

}
