package variaveis;

public class Primitivos {

	public static void main(String[] args) {
		/*
		 *Tipos primitivos em ordem hierarquica:
		 * boolean => tipo l�gico (true ou false)
		 * char => armazena UM caracter
		 * byte => menor entre os inteiros
		 * short => numeros inteiros
		 * int => numeros inteiros (padr�o)
		 * long => maior entre os inteiros
		 * float => menor precis�o nas casas decimais
		 * double=> maior precis�o nas casas decimais (padr�o)
		 */
		
		/*
		 *Cast: � uma convers�o entre tipos compat�veis, apenas
		 *est�o com hierarquias diferentes 
		 */
		boolean gravida=true;
		char sexo='M';
		byte golsVisitante=0;
		short qtdeCestas=0;
		long cpf=0;
		float nota=0;
		double valorLitroCombustivel=0;
		float desconto = 500 * (float) 0.9;
		cpf = (long) 1.5;
	}

}
