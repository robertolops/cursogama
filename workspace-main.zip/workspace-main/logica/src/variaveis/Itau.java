package variaveis;

public class Itau { 

	// estou na classe mas fora do m�todo
public static void main(String[] args) { // main � o Start Point da aplica��o
	// estou na classe e dentro do m�todo
	System.out.print("Ol� mundo");
	
	
}
	
	
}
