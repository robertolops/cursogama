package repeticao;

import javax.swing.JOptionPane;

public class ExemploWhileTorto {

	public static void main(String[] args) {
		char resposta='S';
		while(resposta=='S') {
			int valor1 = Integer.parseInt(JOptionPane.showInputDialog("Valor 1"));
			int valor2 = Integer.parseInt(JOptionPane.showInputDialog("Valor 2"));
			char opcao = JOptionPane.showInputDialog("Digite o operador aritm�tico").charAt(0);
			if (opcao=='+') {
				System.out.println("Soma: " + (valor1+valor2));
			}else if (opcao=='-') {
				System.out.println("Subtracao: " + (valor1-valor2));
			}else if (opcao=='*') {
				System.out.println("Multiplicacao: " + (valor1*valor2));
			}else if (opcao=='/') {
				System.out.println("Divis�o: " + (valor1/valor2));
			}else {
				System.out.println("Opera��o n�o reconhecida!");
			}
			resposta = JOptionPane.showInputDialog("Digite <S> para continuar").toUpperCase().charAt(0);
		}
	}
}
