package repeticao;

import javax.swing.JOptionPane;
public class ExercicioGeral {
	public static void main(String[] args) {
		String nome="";
		int idade=0;
		char resposta=0;
		int qtdeMaiores=0;
		int totalIdades=0;
		int qtdePessoas=0;
		String nomeJovem="";
		String nomeExperiente="";
		int idadeJovem=0;
		int idadeExperiente=0;
		do {
			nome=JOptionPane.showInputDialog("Nome").toUpperCase();
			idade=Integer.parseInt(JOptionPane.showInputDialog("Idade"));
			totalIdades= totalIdades+idade;
			qtdePessoas++;	
			if (qtdePessoas==1) {
				nomeExperiente=nome;
				idadeExperiente=idade;
				nomeJovem=nome;
				idadeJovem=idade;
			}else {
				if (idade>idadeExperiente) {
					nomeExperiente = nome;
					idadeExperiente = idade;
				}else if (idade<idadeJovem) {
					nomeJovem=nome;
					idadeJovem=idade;
				}
			}
			if (idade>17) {
				qtdeMaiores++;
			}
			resposta = JOptionPane.showInputDialog("Digite <S> para continuar").toUpperCase().charAt(0);
		}while(resposta=='S');
		System.out.println("Qtde de Pessoas maiores de idade: " + qtdeMaiores);
		System.out.println("M�dia de idade: "  + (totalIdades/qtdePessoas));
		System.out.println(nomeExperiente + " � o mais experiente com " + idadeExperiente + " anos");
		System.out.println(nomeJovem + " � o mais jovem com " + idadeJovem+ " anos");
	}

}
