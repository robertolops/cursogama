package br.com.projeto.conexao;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexao {
	//Excecoes: checked (SQLException) => AC //// unchecked (NumberFormatException) => DC
	public static Connection conectar() throws Exception {
		return DriverManager.getConnection
				("jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL",
				"pf0709","Fgrd32i");
	}
}
