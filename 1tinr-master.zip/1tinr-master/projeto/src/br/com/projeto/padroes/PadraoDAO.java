package br.com.projeto.padroes;

import java.util.List;

/*
 * Design Pattern => 
 * DAO Generics => criar um interface com os m�todos padr�es para todo 
 * DAO do seu projeto, usando um tipo especifico (<T>).
 * 
 * DTO => criar um classe JavaBeans com caracter�sticas pr�prias, como:
 * 		a-) atributos privados
 * 		b-) getters and setters
 * 		c-) construtor cheio e vazio
 * 
 * BO => isolar as regras de neg�cio em um camada com m�todos est�ticos.
 */
public interface PadraoDAO<T> {

	void close() throws Exception;
	int deleteById(int id) throws Exception;
	boolean add(T objeto) throws Exception;
	T getById(int id) throws Exception;
	List<T> getAll() throws Exception;
	
}
