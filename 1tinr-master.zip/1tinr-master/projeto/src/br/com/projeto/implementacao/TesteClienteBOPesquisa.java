package br.com.projeto.implementacao;

import java.util.List;

import javax.swing.JOptionPane;

import br.com.projeto.beans.Cliente;
import br.com.projeto.bo.ClienteBO;
import br.com.projeto.excecao.Excecoes;

public class TesteClienteBOPesquisa {

	public static void main(String[] args) {
		
		try {
			char resp = JOptionPane.showInputDialog
					("Digite:\n<1> Pesquisar por Nome\n<2> Pesquisar por c�digo").charAt(0);
			if (resp=='1') {
				int cod = Integer.parseInt(JOptionPane.showInputDialog("C�digo"));
				if (cod<1) {
					System.out.println("C�digo negativo");
				}else {
					Cliente resposta = ClienteBO.pesquisarPorNumero(cod);
					System.out.println("Nome: " + resposta.getNome());
					System.out.println("ID:" + resposta.getId());
					System.out.println("Classifica��o:" + resposta.getEstrelas());
				}
				
			}else if (resp=='2') {
				String nome = JOptionPane.showInputDialog("Digite o nome").toUpperCase();
				List<Cliente> resposta = ClienteBO.pesquisarPorNome(nome);
				for (Cliente objeto : resposta) {
					System.out.println("Nome: " + objeto.getNome());
					System.out.println("ID:" + objeto.getId());
					System.out.println("Classifica��o:" + objeto.getEstrelas());
				}
			}else {
				System.out.println("Op��o inv�lida!!!!");
			}	
		}catch(Exception e) {
			System.out.println(Excecoes.tratarExcecao(e));
		}

	}

}
