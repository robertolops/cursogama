package br.com.projeto.implementacao;

import javax.swing.JOptionPane;

import br.com.projeto.dao.ClienteDAO;
import br.com.projeto.excecao.Excecoes;

public class TesteApagarCliente {

	public static void main(String[] args) {
		try {
			ClienteDAO dao = new ClienteDAO();
			System.out.println(
					dao.deleteById(
							Integer.parseInt(
									JOptionPane.showInputDialog(
											"ID"))));
			dao.close();
		}catch(Exception e) {
			System.out.println(Excecoes.tratarExcecao(e));
		}
	}

}
