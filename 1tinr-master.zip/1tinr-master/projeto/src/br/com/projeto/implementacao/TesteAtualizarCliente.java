package br.com.projeto.implementacao;

import javax.swing.JOptionPane;

import br.com.projeto.dao.ClienteDAO;
import br.com.projeto.excecao.Excecoes;

public class TesteAtualizarCliente {

	public static void main(String[] args) {
		try {
			ClienteDAO dao = new ClienteDAO();
			System.out.println("Atualizado: " + 
					dao.levelUp(JOptionPane.showInputDialog("Digite o nome")) + 
					" cliente(s)");
			dao.close();
		}catch(Exception e) {
			System.out.println(Excecoes.tratarExcecao(e));
		}

	}

}
