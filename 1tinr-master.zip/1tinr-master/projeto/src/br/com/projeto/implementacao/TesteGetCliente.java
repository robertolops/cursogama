package br.com.projeto.implementacao;

import javax.swing.JOptionPane;

import br.com.projeto.beans.Cliente;
import br.com.projeto.dao.ClienteDAO;
import br.com.projeto.excecao.Excecoes;

public class TesteGetCliente {

	public static void main(String[] args) {
		try {
			ClienteDAO dao = new ClienteDAO();
			Cliente resposta = 
				dao.getCliente(Integer.parseInt(JOptionPane.showInputDialog("ID")));
			System.out.println("Cliente..: " + resposta.getNome());
			System.out.println("C�digo...: " + resposta.getId());
			System.out.println("Estrelas.: " + resposta.getEstrelas());
			dao.close();
		}catch(Exception e) {
			System.out.println(Excecoes.tratarExcecao(e));
		}
	}

}
