package br.com.projeto.implementacao;

import javax.swing.JOptionPane;

import br.com.projeto.beans.Cliente;
import br.com.projeto.bo.ClienteBO;
import br.com.projeto.excecao.Excecoes;

public class TesteClienteBONovo {

	public static void main(String[] args) {
		try {
			System.out.println
					(ClienteBO.novo
					(new Cliente
					(JOptionPane.showInputDialog("Nome"),
					Integer.parseInt(JOptionPane.showInputDialog("Estrelas")),
					Integer.parseInt(JOptionPane.showInputDialog("ID"))
					)));
		}catch(Exception e) {
			System.out.println(Excecoes.tratarExcecao(e));
		}
	}

}
