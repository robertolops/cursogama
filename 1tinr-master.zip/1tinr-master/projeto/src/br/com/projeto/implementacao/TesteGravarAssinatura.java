package br.com.projeto.implementacao;

import javax.swing.JOptionPane;

import br.com.projeto.beans.Assinatura;
import br.com.projeto.beans.Cliente;
import br.com.projeto.dao.AssinaturaDAO;
import br.com.projeto.excecao.Excecoes;

public class TesteGravarAssinatura {

	public static void main(String[] args) {
		try {
			AssinaturaDAO dao = new AssinaturaDAO();
			dao.add(
					new Assinatura(
							Integer.parseInt(JOptionPane.showInputDialog("ID")),
							new Cliente(
									"",
									0,
									Integer.parseInt(JOptionPane.showInputDialog("ID Cliente"))
									),
							JOptionPane.showInputDialog("Descricao").toUpperCase(),
							Double.parseDouble(JOptionPane.showInputDialog("Valor")),
							JOptionPane.showInputDialog("Data").toUpperCase()
							)
					);
			System.out.println("Cadastrado");
			dao.close();
		}catch(Exception e) {
			System.out.println(Excecoes.tratarExcecao(e));
		}

	}

}
