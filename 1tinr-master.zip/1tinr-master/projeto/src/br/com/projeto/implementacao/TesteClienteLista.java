package br.com.projeto.implementacao;

import java.util.ArrayList;
import java.util.List;

import br.com.projeto.beans.Cliente;
import br.com.projeto.dao.ClienteDAO;
import br.com.projeto.excecao.Excecoes;

public class TesteClienteLista {

	public static void main(String[] args) {
		try {
						
			ClienteDAO dao = new ClienteDAO();
			List<Cliente> resultado = dao.getClientePorNome("");
			for(Cliente obj : resultado) {
				System.out.println("Classifica��o:" + obj.getEstrelas());
				System.out.println("Nome: " + obj.getNome());
				System.out.println("ID:" + obj.getId());
				System.out.println("================");
			}
			dao.close();
		}catch(Exception e) {
			System.out.println(Excecoes.tratarExcecao(e));
		}
	}

}
