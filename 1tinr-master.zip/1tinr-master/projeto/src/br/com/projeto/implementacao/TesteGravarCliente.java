package br.com.projeto.implementacao;

import javax.swing.JOptionPane;

import br.com.projeto.beans.Cliente;
import br.com.projeto.dao.ClienteDAO;
import br.com.projeto.excecao.Excecoes;

public class TesteGravarCliente {

	public static void main(String[] args) {
		try {
			ClienteDAO dao = new ClienteDAO();
			System.out.println(
					dao.add(
							new Cliente(
									JOptionPane.showInputDialog("Nome").toUpperCase(),
									Integer.parseInt(JOptionPane.showInputDialog("Classificacao")),
									Integer.parseInt(JOptionPane.showInputDialog("ID"))
									)
							)
					);
			dao.close();
		}catch(Exception e) {
			System.out.println(Excecoes.tratarExcecao(e));
		}
	}

}
