package br.com.projeto.excecao;

public class Excecoes {

	public static String tratarExcecao(Exception e) {
		if (e instanceof NullPointerException) {
			return "Objeto Nulo";
		}else if (e instanceof NumberFormatException) {
			return "N�mero inv�lido";
		}else if (e instanceof ArrayIndexOutOfBoundsException) {
			return "Vetor estourou";
		}else {
			e.printStackTrace();
			return "Excecao n�o tratada";	
		}
	}
}


/*
public abstract class Pessoa{}

PessoaFisica extends Pessoa{}

PessoaJuridica extends Pessoa{}

Pessoa pessoa = new Pessoa(); // nao pode instanciar
PessoaJuridica pj = new PessoaJuridica(); // n�o � a melhor forma

Pesssoa pessoa = new PessoaJuridica(); // isso � top

pessoa = new PessoaFisica();


pessoa = new PessoaJuridica();

Exception e = new NullPointerException();

*/





