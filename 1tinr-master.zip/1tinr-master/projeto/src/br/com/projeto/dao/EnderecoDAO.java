package br.com.projeto.dao;

import java.util.List;

import br.com.projeto.beans.Endereco;
import br.com.projeto.padroes.PadraoDAO;

public class EnderecoDAO implements PadraoDAO<Endereco>{

	@Override
	public void close() throws Exception {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int deleteById(int id) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean add(Endereco objeto) throws Exception {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Endereco getById(int id) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Endereco> getAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

}
