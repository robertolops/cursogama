package br.com.projeto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import br.com.projeto.beans.Cliente;
import br.com.projeto.conexao.Conexao;
import br.com.projeto.padroes.PadraoDAO;

//DAO => Data Access Object
//CRUD => Create / Read / Update / Delete
/**
 * Realiza as opera��es de CRUD envolvendo o beans
 * Cliente a tabela TB_TIN_CLIENTE.
 * 
 * @author Bruno Melniski
 * @author Humberto Sousa
 * @version 152.0
 * @since 1.0
 * @see br.com.projeto.beans.Cliente
 * @see br.com.projeto.bo.ClienteBO
 */
public class ClienteDAO implements PadraoDAO<Cliente>{
	
	private Connection con;
	private PreparedStatement stmt;
	private ResultSet rs;
	/**
	 * M�todo utilizado para fechar a conexao no ClienteBO.
	 * @author Bruno Melniski
	 * @return sem retorno
	 * @param sem parametros 
	 * @throws lan�a a exce��o para a classe que invoca o m�todo
	 */
	public void close() throws Exception {
		con.close();
	}

	public ClienteDAO() throws Exception{
		con = Conexao.conectar();
	}
	/**
	 * Metodo para exclus�o do Cliente pelo ID
	 * @return int referente a qtde de cliente(s) excluido(s)
	 * @param id refere-se a chave primaria da tabela do Cliente
	 * @throws Exception lanca a exce��o para quem invocou
	 * @author Bruno Melniski
	 */
	public int deleteById(int id) throws Exception{
		stmt = con.prepareStatement
				("DELETE FROM TB_TIN_CLIENTE WHERE NR_CLIENTE=?");
		stmt.setInt(1, id);
		return stmt.executeUpdate();
	}
	
	public boolean add(Cliente objeto) throws Exception {
		stmt = con.prepareStatement
				("INSERT INTO TB_TIN_CLIENTE (NR_CLIENTE, NM_CLIENTE, QT_ESTRELAS) "
						+ "VALUES (?, ?, ?)");
		
		stmt.setInt(1, objeto.getId());
		stmt.setString(2, objeto.getNome());
		stmt.setInt(3, objeto.getEstrelas());
		return stmt.execute();	
	}
	
	public int levelUp(String nome) throws Exception{
		stmt = con.prepareStatement
	("UPDATE TB_TIN_CLIENTE SET QT_ESTRELAS=QT_ESTRELAS+1 WHERE NM_CLIENTE LIKE ?");
		stmt.setString(1, "%" + nome + "%");
		return stmt.executeUpdate();
	}
	
	public Cliente getCliente(int id)throws Exception {
		stmt = con.prepareStatement
				("SELECT * FROM TB_TIN_CLIENTE WHERE NR_CLIENTE = ?");
		stmt.setInt(1, id);
		rs = stmt.executeQuery();
		Cliente objeto = new Cliente();
		if (rs.next()) {
			objeto.setEstrelas(rs.getInt("QT_ESTRELAS"));
			objeto.setId(rs.getInt("NR_CLIENTE"));
			objeto.setNome(rs.getString("NM_CLIENTE"));
		}
		return objeto;
	}
	
	public List<Cliente> getClientePorNome(String nome) throws Exception{
		stmt = con.prepareStatement
				("SELECT * FROM TB_TIN_CLIENTE WHERE NM_CLIENTE LIKE ?");
		stmt.setString(1, "%" + nome + "%");
		List<Cliente> lista = new ArrayList<Cliente>();
		rs = stmt.executeQuery();
		while(rs.next()) {
			lista.add(new Cliente(
					rs.getString("NM_CLIENTE"),
					rs.getInt("QT_ESTRELAS"),
					rs.getInt("NR_CLIENTE")
					));
		}
		return lista;
	}

	@Override
	public Cliente getById(int id) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Cliente> getAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}








	
	
}










