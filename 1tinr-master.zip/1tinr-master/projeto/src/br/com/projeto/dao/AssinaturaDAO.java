package br.com.projeto.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;

import br.com.projeto.beans.Assinatura;
import br.com.projeto.conexao.Conexao;
import br.com.projeto.padroes.PadraoDAO;

public class AssinaturaDAO implements PadraoDAO<Assinatura>{

	private PreparedStatement stmt;
	private Connection con;
	private ResultSet rs;
	// execute() ou executeUpdate() => INSERT/DELETE/UPDATE
	// executeQuery() => SOMENTE para SELECT
	public Assinatura getById(int id)throws Exception{
		stmt = con.prepareStatement("SELECT * FROM TB_TIN_ASSINATURA WHERE NR_ID=?");
		stmt.setInt(1, id);
		rs = stmt.executeQuery();
		Assinatura resultado = new Assinatura();
		if (rs.next()) {
			resultado.setData(rs.getString("DT_CADASTRO"));
			resultado.setDescricao(rs.getString("NM_DESCRICAO"));
			resultado.setId(rs.getInt("NR_ID"));
			resultado.setValor(rs.getDouble("VL_ASSINATURA"));
			//ATEN��O NA LINHA ABAIXO
			resultado.getCliente().setId(rs.getInt("NR_CLIENTE"));
		}
		return resultado;
	}
	
	
	public AssinaturaDAO() throws Exception{
		con = Conexao.conectar();
	}
	public boolean add(Assinatura objeto) throws Exception{
		stmt = con.prepareStatement("INSERT INTO TB_TIN_ASSINATURA "
				+ "(NR_ID, DT_CADASTRO, NM_DESCRICAO, VL_ASSINATURA, NR_CLIENTE) "
				+ "VALUES (?,?,?,?,?)");
		stmt.setInt(1, objeto.getId());
		stmt.setString(2, objeto.getData());
		stmt.setString(3, objeto.getDescricao());
		stmt.setDouble(4, objeto.getValor());
		stmt.setInt(5, objeto.getCliente().getId());
		return stmt.execute();
	}
	public void close() throws Exception {
		con.close();
		
	}
	@Override
	public int deleteById(int id) throws Exception {
		// TODO Auto-generated method stub
		return 0;
	}


	@Override
	public List<Assinatura> getAll() throws Exception {
		// TODO Auto-generated method stub
		return null;
	}


	



	

	
}





