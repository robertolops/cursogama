package br.com.projeto.bo;

import br.com.projeto.beans.Assinatura;
import br.com.projeto.beans.Cliente;
import br.com.projeto.dao.AssinaturaDAO;
import br.com.projeto.dao.ClienteDAO;

public class AssinaturaBO {

	
	private static boolean validarData(String data) {
		byte dia = Byte.parseByte(data.substring(0,2));
		byte mes = Byte.parseByte(data.substring(3,5));
		short ano = Short.parseShort(data.substring(6));
		if (dia<1 || dia >31) {
			return false;
		}
		if (mes<1 || mes>12) {
			return false;
		}
		if (ano<1900) {
			return false;
		}
		return true;
	}
	
	public static String novo(Assinatura objeto)throws Exception{
		AssinaturaDAO dao = new AssinaturaDAO();
		ClienteDAO clidao = new ClienteDAO();
		//requisitos funcionais
		//Verificar se o ID da Assinatura j� existe, caso exista n�o podemos cadastrar
		Assinatura resposta = dao.getById(objeto.getId());
		if (resposta.getId()!=0) {
			//fazer na proxima aula o update
			return "ID j� existe!";
		}
		if (objeto.getDescricao().length()>50) {
			return "Descri��o muito grande!";
		}
		if (objeto.getDescricao()==null) {
			return "Descri��o est� nula";
		}
		Cliente respostacli = clidao.getCliente(objeto.getCliente().getId());
		if (respostacli.getId()==0) {
			return "Cliente n�o existe";
		}
		
		//regras de neg�cio
		if (objeto.getId()<1) {
			return "ID inv�lido";
		}
		if (objeto.getDescricao().length()<5) {
			return "Descri��o incompleta";
		}
		if (objeto.getValor()<10) {
			return "Valor n�o compat�vel";
		}
		
		if (validarData(objeto.getData())==false) {
			return "Data inv�lida";
		}
		//padroniza��o
		objeto.setDescricao(objeto.getDescricao().toUpperCase());
		
		dao.close();
		clidao.close();
		return "Cadastrado com sucesso!";
	}
	
}
