package br.com.projeto.bo;

import java.util.ArrayList;
import java.util.List;

import br.com.projeto.beans.Cliente;
import br.com.projeto.dao.ClienteDAO;

/*
 * BO => Business Object
 * Camada de Neg�cios
 */
public class ClienteBO {

	public static boolean novo(Cliente cliente) throws Exception{
		if (cliente.getNome().length()<5 || cliente.getNome().length()>30) {
			throw new RuntimeException("Ajuste os caracteres do nome");
			//return false;
		}
		
		if (cliente.getEstrelas()<1 || cliente.getEstrelas()>5) {
			throw new RuntimeException("Ajuste a classifica��o");
		}
		
		ClienteDAO dao = new ClienteDAO();
		
		Cliente resultado = dao.getCliente(cliente.getId());
		if (resultado.getId()!=0) {
			throw new RuntimeException("ID j� existe");
		}
		
		cliente.setNome(cliente.getNome().toUpperCase());
		
		dao.add(cliente);
		dao.close();
		return true;
	}
	
	public static Cliente pesquisarPorNumero(int num) throws Exception{
		if (num<1) {
			throw new RuntimeException("Codigo inv�lido");
		}
		ClienteDAO dao = new ClienteDAO();
		Cliente resposta = dao.getCliente(num);
		dao.close();
		return resposta;
	}
	
	public static List<Cliente> pesquisarPorNome(String nome) throws Exception{
		if (nome == null) {
			return new ArrayList<Cliente>();
		}
		ClienteDAO dao = new ClienteDAO();
		List<Cliente> lista = dao.getClientePorNome(nome);
		dao.close();
		return lista;
	}
	
	
}





















