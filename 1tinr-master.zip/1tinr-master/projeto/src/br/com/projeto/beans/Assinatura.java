package br.com.projeto.beans;

public class Assinatura {
	private int id;
	private Cliente cliente;
	private String descricao;
	private double valor;
	private String data;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public Assinatura(int id, Cliente cliente, String descricao, double valor, String data) {
		super();
		this.id = id;
		this.cliente = cliente;
		this.descricao = descricao;
		this.valor = valor;
		this.data = data;
	}
	public Assinatura() {
		super();
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	
}
