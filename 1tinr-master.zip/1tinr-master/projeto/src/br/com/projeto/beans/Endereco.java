package br.com.projeto.beans;

public class Endereco {

}
