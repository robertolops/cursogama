package br.com.projeto.beans;

/*
 * Design Pattern => DTO Data Transfer Object
 * - todos atributos privados
 * - todo atributo deve ter um getter e um setter
 * - um construtor cheio e outro vazio
 */

public class Cliente {
	private String nome;
	private int estrelas;
	private int id;
	
	public Cliente() {
		super();
	}
	public Cliente(String nome, int estrelas, int id) {
		super();
		this.nome = nome;
		this.estrelas = estrelas;
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public int getEstrelas() {
		return estrelas;
	}
	public void setEstrelas(int estrelas) {
		this.estrelas = estrelas;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}


}
