package conexao;

import java.sql.Connection;
import java.sql.DriverManager;

import br.com.conexao.excecao.Excecoes;

public class TesteConexao {

	public static void main(String[] args) {
		try{ //Checked�s => AC
			Connection minhaConexao = 
				DriverManager.getConnection
				("jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL","pf0708","xxxxxx");
			System.out.println("Abriu a conex�o");
			minhaConexao.close();
		}catch(Exception e) {
			System.out.println(Excecoes.tratarExcecao(e));
		}

	}

}
