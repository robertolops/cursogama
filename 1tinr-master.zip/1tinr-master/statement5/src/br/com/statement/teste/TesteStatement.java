package br.com.statement.teste;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.swing.JOptionPane;

import br.com.statement.excecao.Excecoes;

public class TesteStatement {

	public static void main(String[] args) {
		Connection minhaConexao = null;
		try{ //Checked�s => AC
			minhaConexao = DriverManager.getConnection
				("jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL","pf0708","xxxxxx");
			System.out.println("Abriu a conex�o");
			
			int varNumero = Integer.parseInt(JOptionPane.showInputDialog("Digite o n�mero"));
			String varNome= JOptionPane.showInputDialog("Digite parte do nome").toUpperCase();
			
			PreparedStatement estrutura = minhaConexao.prepareStatement
					("SELECT * FROM TB_TIN_CLIENTE WHERE NR_CLIENTE=? AND NM_CLIENTE=?");
			estrutura.setInt(1, varNumero);
			estrutura.setString(2, varNome);
			// SQL Injection => ZE'OR'1'='1
			ResultSet rs = estrutura.executeQuery(); //.executeQuery() => para executar pesquisas "select�s"
			if(rs.next()) {
				System.out.println("Seja bem vindo, sr(a): " + rs.getString("NM_CLIENTE"));
			}else {
				System.out.println("Login inv�lido");
			}
			
		}catch(Exception e) {
			System.out.println(Excecoes.tratarExcecao(e));
		}finally {
			try {
				minhaConexao.close();
			}catch(Exception e) {
				System.out.println(Excecoes.tratarExcecao(e));
			}
		}

	}

}
