package br.com.falhas.teste;

import br.com.falhas.excecao.Excecoes;

public class ImplementacaoPrincipal {
	public static void main(String[] args) {
		try {
		//
		//l�djls,sdljsdnf s
		//
		//

		}catch(Exception e) {
			System.out.println(Excecoes.tratarExcecao(e));
		}

	}
}
