package br.com.falhas.teste;

import br.com.falhas.beans.Produto;
import br.com.falhas.conexao.Conexao;
import br.com.falhas.excecao.Excecoes;

public class TesteFalha {

	public static void main(String[] args) {
		String palavra = "";
		try { //bloco try somente as linhas onde pode ocorrer exce��o
			
			new Conexao().conectar();
			
			Produto objeto = new Produto();
			objeto.setQtde(-5);
			
			int numero = Integer.parseInt("abc");
			System.out.println(numero);
			
			System.out.println("Qtde Letras: " + palavra.length());
			
			int numeros[] = new int[3];
			numeros[0] = 15;
			numeros[1] = 152;
			numeros[2] = 6;
			
			// as linhas do catch somente ser�o executadas se ocorrer uma exce��o
		}catch(Exception e) {
			System.err.println(Excecoes.tratarExcecao(e));
		}finally { // vai ser executado independentemente da excecao
			System.out.println("At� logo...");
		}
	}

}
