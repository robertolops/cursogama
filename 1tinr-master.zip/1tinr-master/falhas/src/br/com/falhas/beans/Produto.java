package br.com.falhas.beans;
/*
 * Beans / JavaBeans / DTO (nome real - Data Transfer Object) / TO / Modelo
 * 1� Construtor cheio e vazio
 * 2� Getter e setter para cada atributo
 * 3� Todos os atributos privados
 */
public class Produto {
	private int id;
	private String descricao;
	private int qtde;
	private double valor;
	
	public Produto(int id, String descricao, int qtde, double valor) {
		super();
		this.id = id;
		this.descricao = descricao;
		this.qtde = qtde;
		this.valor = valor;
	}
	public Produto() {
		super();
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {

		this.id = id;
	}
	public String getDescricao() {
		return descricao;
	}
	public void setDescricao(String descricao) {
		this.descricao = descricao;
	}
	public int getQtde() {
		return qtde;
	}
	public void setQtde(int qtde) {
		if (qtde<1) {
			throw new RuntimeException("Gerando cx 2...");
		}
		this.qtde = qtde;
	}
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	
}
