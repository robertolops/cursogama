package br.com.falhas.conexao;

import java.sql.DriverManager;

public class Conexao {

	// Aqui temos uma excecao do tipo Checked 
	// (verificada antes de compilar)
	public void conectar() throws Exception {
		DriverManager.getConnection("");
	}
}
