package br.com.conexao.excecao;

import java.sql.SQLException;

public class Excecoes {

	public static String tratarExcecao(Exception e) {
		if (e instanceof NullPointerException) {
			return "Objeto Nulo";
		}else if (e instanceof NumberFormatException) {
			return "N�mero inv�lido";
		}else if (e instanceof ArrayIndexOutOfBoundsException) {
			return "Vetor estourou";
		//}else if (e instanceof SQLException) {
			//return "Ocorreu um erro com o BD";
		}else {
			e.printStackTrace();
			return "Excecao n�o tratada";	
		}
	}
}






