package conexao;

import java.sql.Connection;
import java.sql.DriverManager;

import br.com.conexao.excecao.Excecoes;

public class TesteConexao {

	public static void main(String[] args) {
		Connection minhaConexao = null;
		try{ //Checked�s => AC
			minhaConexao = 
				DriverManager.getConnection
				("jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL","pf0708","xxxxxx");
			System.out.println("Abriu a conex�o");
			//
			int x = Integer.parseInt("1");
			//
			//
		}catch(Exception e) {
			System.out.println(Excecoes.tratarExcecao(e));
		}finally {
			try {
				minhaConexao.close();
			}catch(Exception e) {
				System.out.println(Excecoes.tratarExcecao(e));
			}
		}

	}

}
