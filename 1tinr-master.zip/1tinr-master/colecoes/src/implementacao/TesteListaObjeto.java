package implementacao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import modelo.Cargo;

public class TesteListaObjeto {

	public static void main(String[] args) {
		List<Cargo> lista = new ArrayList<Cargo>();
		lista.add(new Cargo("DBA", "JUNIOR", 8000));
		lista.add(new Cargo("ESTAGIARIO", "SENIOR", 4500));
		lista.add(new Cargo("ANALISTA", "JUNIOR", 5000));
		//System.out.println(lista.get(1).getNome());
		Collections.sort(lista);
		double total=0;
		for (Cargo obj : lista) {
			total+=obj.getSalario();
			System.out.println(obj.getNome());
			System.out.println(obj.getNivel());
			System.out.println(obj.getSalario());
			System.out.println("=======================");
		}
		System.out.println("Total: " + total);
	}
}
