package implementacao;

import java.util.HashSet;
import java.util.Set;

public class TesteSet {

	public static void main(String[] args) {
		Set<String> lista = new HashSet<String>();
		lista.add("DBA");
		lista.add("FRONT");
		lista.add("BACK");
		lista.add("ANALISTA");
		lista.add("DBA");
		System.out.println(lista);
		// N�o funcionam pq o Set n�o possui indice
		//System.out.println(lista.get(0));
		//Collections.sort(lista);
	}

}
