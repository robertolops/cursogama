package implementacao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TesteLista {

	/*
	 * Collection Framework (API para um conjunto de dados tempor�rios)
	 */
	public static void main(String[] args) {
		List<String> lista = new ArrayList<String>();
		lista.add("DBA");
		lista.add("FRONT");
		lista.add("BACK");
		lista.add("DBA");
		lista.add("ANALISTA");
		System.out.println("Desordenada: " + lista);
		System.out.println("Segundo elemento da lista: " + lista.get(1));
		Collections.sort(lista);
		System.out.println("Ordenada: " + lista);
		lista.remove(2);
		System.out.println("Sem o terceiro elemento: " + lista);
		
		
		
		

	}

}
