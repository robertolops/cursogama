package br.com.statement.teste;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import br.com.statement.excecao.Excecoes;

public class TesteStatement {

	public static void main(String[] args) {
		Connection minhaConexao = null;
		try{ //Checked�s => AC
			minhaConexao = DriverManager.getConnection
				("jdbc:oracle:thin:@oracle.fiap.com.br:1521:ORCL","pf0708","xxxxxx");
			System.out.println("Abriu a conex�o");
			
			Statement estrutura = minhaConexao.createStatement();
			
			//.executeQuery() => para executar pesquisas "select�s"
			ResultSet rs = estrutura.executeQuery("SELECT * from TB_TIN_CLIENTE"); 
			
			while(rs.next()) {
				System.out.println("Cliente.......: " + rs.getString("NM_CLIENTE"));
				System.out.println("ID Cliente....: " + rs.getInt("NR_CLIENTE"));
				System.out.println("Classifica��o.: " + rs.getInt("QT_ESTRELAS"));
				System.out.println("============================================");
			}
			
		}catch(Exception e) {
			System.out.println(Excecoes.tratarExcecao(e));
		}finally {
			try {
				minhaConexao.close();
			}catch(Exception e) {
				System.out.println(Excecoes.tratarExcecao(e));
			}
		}

	}

}
