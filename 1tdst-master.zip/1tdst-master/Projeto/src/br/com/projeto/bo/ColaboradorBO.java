package br.com.projeto.bo;

import br.com.projeto.beans.Cargo;
import br.com.projeto.beans.Colaborador;
import br.com.projeto.dao.ColaboradorDAO;

public class ColaboradorBO {

	public static int novo(Colaborador objeto) throws Exception{
		if (objeto.getCpf().length()!=14) {
			throw new RuntimeException("CPF fora do tamanho");
		}
		if (objeto.getId()<1) {
			throw new RuntimeException("ID");
		}
		if (objeto.getCargo()==null) {
			throw new RuntimeException("Objeto nulo");
		}
		if (objeto.getCargo().getId()<1) {
			throw new RuntimeException("ID Cargo");
		}
		// verificar se o cargo informado existe (ELE DEVE EXISTIR)
		Cargo resposta = CargoBO.pesquisarCargo(objeto.getCargo().getId());
		if (resposta.getId()==0) {
			throw new RuntimeException("ID cargo");
		}
		// verificar se o Colaborador j� existe
		ColaboradorDAO dao = new ColaboradorDAO();
		dao.abrir();
		Colaborador resposta2 = dao.getById(objeto.getId());
		if (resposta2.getId()!=0) {
			dao.fechar();
			throw new RuntimeException("ID Colaborador");
		}
		objeto.setNome(objeto.getNome().toUpperCase());
		
		dao.add(objeto);
		dao.fechar();
		return 1;
	}
}
