package br.com.projeto.implementacao;

import br.com.projeto.beans.Cargo;
import br.com.projeto.beans.Colaborador;
import br.com.projeto.bo.ColaboradorBO;
import br.com.projeto.exception.Excecao;

public class TesteColaboradorBO {

	public static void main(String[] args) {
		try {
			Colaborador objeto = new Colaborador();
			objeto.setAdmissao("19/10/2020");
			objeto.setCpf("123.456.789-00");
			objeto.setNome("Tio Phill");
			objeto.setId(10);
			objeto.setCargo(new Cargo(
					null,
					null,
					0,
					1
					));
			System.out.println(ColaboradorBO.novo(objeto));
		}catch(Exception e) {
			e.printStackTrace();
			System.out.println(Excecao.tratarExcecao(e));
		}
	}
}
