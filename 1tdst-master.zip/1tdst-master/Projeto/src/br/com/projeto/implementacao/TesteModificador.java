package br.com.projeto.implementacao;

import br.com.projeto.beans.Cargo;
import br.com.projeto.beans.Colaborador;
import br.com.projeto.beans.Pessoa;

public class TesteModificador {

	public static void main(String[] args) {
		Cargo cargo = new Cargo();
		
		// Ao inves de criar pela sub e instanciar pela sub
		Colaborador c = new Colaborador();
		
		// Procure.... criar pela super e instanciar pela sub
		Pessoa p = new Colaborador("","","",0,new Cargo(),"","");
		System.out.println(p.getAll());
		
		//Pessoa p2 = new Pessoa();
		
		
	}

}
