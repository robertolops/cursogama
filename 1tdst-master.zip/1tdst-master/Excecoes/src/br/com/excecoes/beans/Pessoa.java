package br.com.excecoes.beans;

public class Pessoa {

}
