package br.com.excecoes.beans;

public class Professor extends Pessoa{

}
