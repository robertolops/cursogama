package br.com.colecoes.implementacao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import br.com.colecoes.beans.Cargo;

public class TesteListObjeto {

	public static void main(String[] args) {
		List<Cargo> lista = new ArrayList<Cargo>();
		lista.add(new Cargo("DBA", "JR", 500));
		lista.add(new Cargo("ESTAGIARIO", "SR", 2500));
		lista.add(new Cargo("DEV", "JR", 4000));
		lista.add(new Cargo("ANALISTA", "JR", 3500));
		//System.out.println(lista.get(1).getAll());
		
		Collections.sort(lista);
		
		for (Cargo obj : lista) {
			System.out.println(obj.getAll());
		}

	}

}
