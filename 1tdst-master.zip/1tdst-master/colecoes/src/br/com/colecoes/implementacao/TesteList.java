package br.com.colecoes.implementacao;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TesteList {

	public static void main(String[] args) {
		/*
		 * Collection Framework => � uma API que permite manipular multiplos dados.
		 */
		//int numeros[] = new int[5];
		List<String> lista = new ArrayList<String>();
		lista.add("DBA");
		lista.add("DEV");
		lista.add("DBA");
		lista.add("ANALISTA");
		lista.add("ESTAGIARIO");
		System.out.println("Desordenada: " + lista);
		Collections.sort(lista);
		System.out.println("Ordenada: "  + lista);
		System.out.println("Segundo elemento: " + lista.get(1));
		lista.remove(2);
		System.out.println("Sem o terceiro elemento: " + lista);
		for (String cargo : lista ) {
			System.out.println("Cargo: " + cargo);
		}
		
		
	}

}
